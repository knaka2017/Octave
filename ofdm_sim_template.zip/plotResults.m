function plotResults(txSig, rxSig, rxSym, m, p)
% plotResults : 時間波形・スペクトル・コンスタレーション等を描画
%-------------------------------------------------------------
figure;
subplot(2,1,1);
plot(real(txSig(1:5*p.fs/1e6))); grid on;
title('送信信号（実部）'); xlabel('サンプル番号'); ylabel('振幅');

subplot(2,1,2);
plot(real(rxSig(1:5*p.fs/1e6))); grid on;
title('受信信号（実部）');

figure;
pspectrum(txSig, p.fs, 'FrequencyLimits',[0 p.fs/2]);
title('送信スペクトル');

figure;
scatter(real(rxSym(:)), imag(rxSym(:)), '.'); axis equal; grid on;
title(sprintf('受信コンスタレーション (EVM=%.2f%%)', 100*m.EVMrms));

fprintf('--- 主要指標 ---\n');
fprintf('BER    : %.3e (%d / %d)\n', m.BER, m.bitErr, m.totalBits);
fprintf('EVMrms : %.2f %% (%.2f dB)\n', 100*m.EVMrms, m.EVMdB);
fprintf('PAPR   : %.2f dB\n', m.PAPR);
end
