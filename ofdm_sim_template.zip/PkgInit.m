function PkgInit()
% PkgInit : 必要パッケージをロード（Octave 用）
%-------------------------------------------------------------
if exist('OCTAVE_VERSION', 'builtin')
    pkg load signal;           % フィルタ設計・窓関数
    pkg load communications;   % QAM / BER など
end
end
