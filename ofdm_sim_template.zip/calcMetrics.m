function m = calcMetrics(txSym, rxSym, bitsTX, p)
% calcMetrics : BER・EVM・PAPR 等をまとめて計算
%-------------------------------------------------------------
k   = log2(p.M);
intsRX = qamdemod(rxSym(:), p.M, 'UnitAveragePower', true);
bitsRX = de2bi(intsRX, k, 'left-msb').'; bitsRX = bitsRX(:);

[m.bitErr, m.BER] = biterr(bitsTX, bitsRX);
m.totalBits = numel(bitsTX);

errVec   = rxSym(:) - txSym(:);
m.EVMrms = rms(errVec) / rms(txSym(:));
m.EVMdB  = 20*log10(m.EVMrms);

txPwr = abs(txSym(:)).^2;
m.PAPR = 10*log10(max(txPwr) / mean(txPwr));
end
