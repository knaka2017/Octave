% main.m : OFDM シミュレーションのトップレベルスクリプト
%-------------------------------------------------------------
clear; clc; close all;
PkgInit();                      % 必要パッケージのロード

param = defaultParam();         % 1. パラメータ設定

[dataBits, txSym] = genData(param);        % 2. データ生成＋変調
txSig            = txOFDM(txSym, param);   % 3. 送信処理
rxSig            = channelModel(txSig, param); % 4. チャネル通過
rxSym            = rxOFDM(rxSig, param);   % 5. 受信処理

metrics = calcMetrics(txSym, rxSym, dataBits, param); % 6. 指標算出
plotResults(txSig, rxSig, rxSym, metrics, param);     % 7. 可視化
