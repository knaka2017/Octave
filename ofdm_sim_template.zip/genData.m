function [bits, sym] = genData(p)
% genData : ビット列生成→M-QAM 変調（ベクトル化）
%-------------------------------------------------------------
rand('state', p.seed);                  % 再現性確保
k      = log2(p.M);                     % ビット/シンボル
numBit = p.N * p.numSym * k;
bits   = randi([0 1], numBit, 1);

% ビット → 整数
ints = bi2de(reshape(bits, k, []).', 'left-msb');
% 整数 → QAM シンボル (平均電力 1 に正規化)
sym   = qammod(ints, p.M, 'UnitAveragePower', true);
sym   = reshape(sym, p.N, []);          % 列＝OFDM シンボル
end
