function txSig = txOFDM(sym, p)
% txOFDM : IFFT・CP 付加で時系列信号生成
%-------------------------------------------------------------
ifftData = ifft(sym, p.N, 1);               % 列ごとに IFFT
withCP   = [ifftData(end-p.CP+1:end, :); ifftData]; % CP 挿入
txSig    = withCP(:);                       % 直列化
% TODO: 過サンプリングやパルス整形が必要ならここで実装
end
