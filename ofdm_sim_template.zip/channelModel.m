function rxSig = channelModel(txSig, p)
% channelModel : シンプルな AWGN チャネル
%-------------------------------------------------------------
rxSig = awgn(txSig, p.SNRdB, 'measured');
% TODO: マルチパス FIR や位相雑音を組み込みたい場合は追加
end
