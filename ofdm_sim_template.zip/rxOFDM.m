function rxSym = rxOFDM(rxSig, p)
% rxOFDM : CP 除去→FFT→(簡易) 等化
%-------------------------------------------------------------
% 受信シンボル列を行列復元
rxMat = reshape(rxSig, p.N + p.CP, []);
rxMat = rxMat(p.CP+1:end, :);          % CP 削除
rxFFT = fft(rxMat, p.N, 1);

% ここではチャネルを理想 (1) と仮定して等化省略
rxSym = rxFFT;
end
